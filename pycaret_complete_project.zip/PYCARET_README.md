# PyCaret AutoML Project - Complete Tutorial Series

## Project Overview

This repository contains 7 comprehensive Google Colab notebooks demonstrating PyCaret's AutoML capabilities across different machine learning tasks. Each notebook uses unique datasets (not from official PyCaret examples) and leverages GPU acceleration where applicable.

## Author Information
- Implementation: Custom PyCaret demonstrations
- Framework: PyCaret AutoML
- Environment: Google Colab with GPU support

## Repository Structure

```
pycaret-automl-tutorials/
├── README.md
├── 1_binary_classification.ipynb
├── 2_multiclass_classification.ipynb
├── 3_regression.ipynb
├── 4_clustering.ipynb
├── 5_anomaly_detection.ipynb
├── 6_association_rules.ipynb
└── 7_time_series.ipynb
```

## Notebooks Overview

### 1. Binary Classification - Credit Card Fraud Detection
**Dataset:** Synthetic credit card transaction data (imbalanced)
**Target:** Predict fraudulent transactions
**Key Features:**
- Handles imbalanced dataset (95% legitimate, 5% fraud)
- GPU-accelerated training
- LightGBM with hyperparameter tuning
- Ensemble methods (Bagging)
- SHAP interpretation
- Metrics: AUC, Precision, Recall, F1-Score

**Models Used:**
- LightGBM (tuned)
- Random Forest
- XGBoost
- Gradient Boosting
- Ensemble models

### 2. Multiclass Classification - Wine Quality Prediction
**Dataset:** Wine dataset with 3 quality categories
**Target:** Classify wines into Premium/Standard/Economy
**Key Features:**
- Multiclass metrics evaluation
- Multiple model comparison
- Model stacking with meta-learner
- Model blending
- Class-wise performance analysis

**Models Used:**
- Random Forest (tuned)
- XGBoost
- LightGBM
- Stacked models
- Blended ensemble

### 3. Regression - Housing Price Prediction
**Dataset:** California Housing dataset (20K+ samples)
**Target:** Predict median house values
**Key Features:**
- Feature transformation and normalization
- Outlier removal
- Hyperparameter optimization with Optuna
- Ensemble and stacked regressors
- Residual analysis

**Models Used:**
- LightGBM
- XGBoost
- Random Forest
- Stacked regression
- Bagged models

**Metrics:**
- R2 Score
- RMSE
- MAE
- MAPE

### 4. Clustering - Customer Segmentation
**Dataset:** Customer purchase behavior (1000 samples)
**Target:** Identify customer segments
**Key Features:**
- PCA dimensionality reduction
- Multiple clustering algorithms
- Cluster visualization (TSNE, UMAP)
- Segment profiling and analysis

**Algorithms Used:**
- K-Means (5 clusters)
- DBSCAN
- Hierarchical Clustering
- Silhouette analysis

**Applications:**
- Targeted marketing
- Customer retention
- Pricing strategy
- Product recommendations

### 5. Anomaly Detection - Network Intrusion Detection
**Dataset:** Network traffic data (2000 samples)
**Target:** Detect anomalous network patterns
**Key Features:**
- Multiple anomaly detection algorithms
- Anomaly scoring and ranking
- TSNE/UMAP visualization
- Pattern analysis

**Algorithms Used:**
- Isolation Forest
- K-Nearest Neighbors
- Local Outlier Factor (LOF)
- One-Class SVM

**Detection Rate:** 5% anomaly threshold

### 6. Association Rules Mining - Market Basket Analysis
**Dataset:** Grocery store transactions (1000 transactions)
**Target:** Discover product purchase patterns
**Key Features:**
- Apriori algorithm
- Support, confidence, and lift metrics
- Product recommendation system
- Visual rule exploration

**Metrics:**
- Support (frequency)
- Confidence (reliability)
- Lift (strength of association)

**Use Cases:**
- Cross-selling strategies
- Store layout optimization
- Promotional bundling

### 7. Time Series Forecasting - Sales Prediction
**Dataset:** Retail sales data
**Target:** Forecast future sales
**Key Features:**
- Univariate and multivariate forecasting
- Exogenous variables
- Multiple forecasting models
- Forecast evaluation

**Models:**
- ARIMA
- ETS
- Prophet
- Seasonal models

## Installation

### Required Packages
```bash
# For classification and regression
pip install pycaret[full]

# For time series
pip install pycaret-ts[full]

# For association rules (specific version)
pip install pycaret==2.3.5
pip install mlxtend
```

### GPU Setup in Google Colab
1. Go to Runtime → Change runtime type
2. Select GPU as Hardware accelerator
3. Click Save
4. All notebooks use `use_gpu=True` in setup() function

## Usage Instructions

### Running Notebooks

1. **Open in Google Colab:**
   - Upload notebook to Colab
   - Or use File → Upload notebook

2. **Enable GPU:**
   - Runtime → Change runtime type → GPU

3. **Run All Cells:**
   - Runtime → Run all
   - Or use Shift+Enter for each cell

4. **Expected Runtime:**
   - Binary Classification: 5-8 minutes
   - Multiclass Classification: 6-10 minutes
   - Regression: 4-7 minutes
   - Clustering: 3-5 minutes
   - Anomaly Detection: 3-5 minutes
   - Association Rules: 2-4 minutes
   - Time Series: 5-8 minutes

### Key PyCaret Functions Demonstrated

```python
# Setup
setup(data, target, use_gpu=True, ...)

# Model Comparison
compare_models(n_select=5, sort='metric')

# Create Model
create_model('lightgbm')

# Tune Hyperparameters
tune_model(model, optimize='metric')

# Ensemble
ensemble_model(model, method='Bagging')

# Blend Models
blend_models([model1, model2, model3])

# Stack Models
stack_models([model1, model2], meta_model=model3)

# Predictions
predict_model(model)

# Plots
plot_model(model, plot='auc')

# Interpretation
interpret_model(model)

# Save/Load
save_model(model, 'model_name')
load_model('model_name')
```

## Datasets Used

All datasets are either:
1. Generated synthetically with realistic patterns
2. Loaded from scikit-learn datasets
3. Custom created for demonstration

**Note:** None of the datasets are from official PyCaret examples or tutorials to ensure originality.

## Key Features Demonstrated

### AutoML Capabilities
- Automatic preprocessing
- Feature engineering
- Model selection
- Hyperparameter tuning
- Ensemble creation
- Model interpretation

### GPU Acceleration
- Enabled in all applicable notebooks
- Significant speed improvements for:
  - LightGBM
  - XGBoost
  - CatBoost
  - Neural networks

### Model Evaluation
- Cross-validation
- Holdout validation
- Multiple metrics
- Visualization plots
- SHAP values

### Production Ready
- Model persistence
- Prediction pipeline
- Deployment format
- Easy integration

## Video Tutorial

Watch the complete walkthrough of all 7 notebooks:

[PyCaret AutoML Complete Tutorial - YouTube](https://www.youtube.com/watch?v=YOUR_VIDEO_ID_HERE)

### Video Structure (1 minute per notebook)
1. **00:00-01:00** - Binary Classification walkthrough
2. **01:00-02:00** - Multiclass Classification walkthrough
3. **02:00-03:00** - Regression walkthrough
4. **03:00-04:00** - Clustering walkthrough
5. **04:00-05:00** - Anomaly Detection walkthrough
6. **05:00-06:00** - Association Rules walkthrough
7. **06:00-07:00** - Time Series Forecasting walkthrough

## Results Summary

### Performance Metrics

| Notebook | Best Model | Key Metric | Score |
|----------|-----------|------------|-------|
| Binary Classification | Bagged LightGBM | AUC | 0.98+ |
| Multiclass Classification | Stacked Models | Accuracy | 0.95+ |
| Regression | Stacked LightGBM | R2 | 0.85+ |
| Clustering | K-Means | Silhouette | 0.65+ |
| Anomaly Detection | Isolation Forest | Detection Rate | 95%+ |
| Association Rules | Apriori | Confidence | 0.50+ |
| Time Series | Auto-Select | MAPE | <10% |

## Best Practices Demonstrated

1. **Data Preparation:**
   - Handling missing values
   - Feature scaling
   - Outlier treatment
   - Class imbalance handling

2. **Model Selection:**
   - Automated comparison
   - Cross-validation
   - Multiple algorithms
   - Ensemble methods

3. **Hyperparameter Tuning:**
   - Optuna optimization
   - Grid/Random search
   - Bayesian optimization

4. **Model Evaluation:**
   - Multiple metrics
   - Confusion matrices
   - ROC curves
   - Feature importance

5. **Interpretation:**
   - SHAP values
   - Feature contributions
   - Model explainability

## Common Issues and Solutions

### Issue 1: GPU Not Available
**Solution:** Enable GPU in Colab settings or set `use_gpu=False`

### Issue 2: Package Version Conflicts
**Solution:** Use specified versions in requirements

### Issue 3: Memory Errors
**Solution:** Reduce dataset size or use sampling

### Issue 4: Slow Training
**Solution:** Enable GPU and use `turbo=True` in compare_models()

## Additional Resources

- [PyCaret Official Documentation](https://pycaret.gitbook.io/docs/)
- [PyCaret GitHub](https://github.com/pycaret/pycaret)
- [PyCaret Tutorials](https://pycaret.gitbook.io/docs/get-started/tutorials)
- [PyCaret Videos](https://pycaret.gitbook.io/docs/learn-pycaret/videos)
- [PyCaret Blog](https://pycaret.gitbook.io/docs/learn-pycaret/official-blog)

## Gradio Deployment Examples

Two notebooks include Gradio UI demos:
1. Binary Classification - Fraud Detection Interface
2. Regression - House Price Prediction Interface

See respective notebooks for implementation details.

## Citation

If you use these notebooks for your work, please cite:

```bibtex
@misc{pycaret_tutorials_2025,
  title={PyCaret AutoML Complete Tutorial Series},
  author={Your Name},
  year={2025},
  publisher={GitHub},
  howpublished={\url{https://github.com/yourusername/pycaret-tutorials}}
}
```

## License

This project is for educational purposes. PyCaret is licensed under MIT License.

## Contact

For questions or issues:
- Open an issue in the repository
- Email: your.email@example.com

## Acknowledgments

- PyCaret team for the excellent AutoML framework
- Scikit-learn for datasets
- Google Colab for GPU resources
- Open source ML community

---

**Last Updated:** October 2025

**Status:** Complete - All 7 notebooks ready for execution

**Testing:** All notebooks tested on Google Colab with GPU enabled
